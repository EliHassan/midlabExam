import React, { useState } from 'react';
import PollDisplay from './PollDisplay';
import UserParticipation from './UserParticipation';
import ThankYouMessage from './ThankYouMessage';
import AnotherUserParticipation from './AnotherUserParticipation';

function App() {
  const [pollData, setPollData] = useState({
    question: 'What is your favorite programming language?',
    choices: [
      { id: 1, label: 'JavaScript', votes: 0 },
      { id: 2, label: 'Python', votes: 0 },
      { id: 3, label: 'Java', votes: 0 },
      { id: 4, label: 'C#', votes: 0 },
    ],
    voted: false,
  });

  const handleVote = (id) => {
    const newPollData = pollData.choices.map((choice) => {
      if (choice.id === id) {
        return { ...choice, votes: choice.votes + 1 };
      }
      return choice;
    });
    setPollData({ ...pollData, choices: newPollData, voted: true });
  };

  const handleReset = () => {
    setPollData({
      question: 'What is your favorite programming language?',
      choices: [
        { id: 1, label: 'JavaScript', votes: 0 },
        { id: 2, label: 'Python', votes: 0 },
        { id: 3, label: 'Java', votes: 0 },
        { id: 4, label: 'C#', votes: 0 },
      ],
      voted: false,
    });
  };

  return (
    <div className="App">
      <h1>Polling App</h1>
      <PollDisplay pollData={pollData} />
      {!pollData.voted && (
        <UserParticipation pollData={pollData} handleVote={handleVote} />
      )}
      {pollData.voted && <ThankYouMessage />}
      <AnotherUserParticipation handleReset={handleReset} />
    </div>
  );
}

export default App;