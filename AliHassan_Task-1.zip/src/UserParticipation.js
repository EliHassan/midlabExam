import React from 'react';

function UserParticipation({ pollData, handleVote }) {
  return (
    <div>
      <h3>Vote:</h3>
      <ul>
        {pollData.choices.map((choice) => (
          <li key={choice.id}>
            <button onClick={() => handleVote(choice.id)}>
              {choice.label}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default UserParticipation;