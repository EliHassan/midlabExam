import React from 'react';

function ThankYouMessage() {
  return (
    <div>
      <h3>Thank you for voting!</h3>
    </div>
  );
}

export default ThankYouMessage;