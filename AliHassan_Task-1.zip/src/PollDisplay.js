import React from 'react';

function PollDisplay({ pollData }) {
  return (
    <div>
      <h2>{pollData.question}</h2>
      <ul>
        {pollData.choices.map((choice) => (
          <li key={choice.id}>
            {choice.label}: {choice.votes}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default PollDisplay;